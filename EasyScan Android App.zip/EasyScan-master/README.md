# EasyScan
Native OCR mobile application integrated with Firebase and Google Cloud Functions.
